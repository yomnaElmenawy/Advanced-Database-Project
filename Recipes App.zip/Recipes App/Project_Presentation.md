# RecipeVault - Project Presentation
## CSE323 Advanced Database Systems

---

## Slide 1: Title
# RecipeVault
### NoSQL Recipe Management System

**Course**: CSE323 Advanced Database Systems  
**Tech Stack**: MongoDB | Node.js/Express | Nginx | Docker

---

## Slide 2: Problem Statement
### Why RecipeVault?

- Traditional systems use relational databases for document-oriented data
- Complex JOIN operations for simple recipe data
- Rigid schemas don't fit varying recipe structures
- Limited native text search capabilities

**Solution**: NoSQL document store with optimized indexes

---

## Slide 3: Objectives
### Project Goals

**Primary**
1. Design NoSQL document store for recipes
2. Build responsive web interface (CRUD)
3. Implement efficient search with MongoDB indexes
4. Deploy with Docker Compose

**Technical**
- Single-collection design (no JOINs)
- Weighted text search index
- Rate-limited API with CORS
- Three-tier architecture

---

## Slide 4: System Architecture
```
Frontend (Nginx) → Security Layer (CORS + Rate Limit)
                            ↓
              Backend (Node.js/Express)
                            ↓
              MongoDB (recipes + Indexes)
```

### Layers
- **Frontend**: HTML/CSS/JS served via Nginx
- **Security**: CORS policy, 100 req/15min rate limit
- **Backend**: Express router, controllers, Mongoose ODM
- **Database**: MongoDB with Text, Category, Timestamp indexes

---

## Slide 5: NoSQL Data Model
### Recipe Document Schema

| Field | Type | Constraint |
|-------|------|------------|
| `name` | String | Required, max:120 |
| `category` | String | Enum (6 values) |
| `ingredients` | String | Newline-separated |
| `instructions` | String | Newline-separated |
| `difficulty` | String | Easy/Medium/Hard |

### NoSQL Benefits
✅ No JOINs - single collection  
✅ Flexible schema  
✅ Plain text storage (zero serialization)  
✅ O(1) lookup by `_id`

---

## Slide 6: Index Strategy
### MongoDB Indexes for Performance

| Index | Fields | Weight/Purpose |
|-------|--------|----------------|
| **Text** | name, ingredients, description | 10:5:1 weighting for search |
| **Category** | category | Fast enum filtering |
| **Timestamp** | createdAt | Sort newest/oldest |

**Result**: Fast queries without external search engines

---

## Slide 7: CRUD Operations
### API Endpoints

| Method | Endpoint | Operation |
|--------|----------|------------|
| GET | `/api/recipes` | List (with search/filter/sort) |
| GET | `/api/recipes/:id` | View single recipe |
| POST | `/api/recipes` | Create new recipe |
| PUT | `/api/recipes/:id` | Update recipe |
| DELETE | `/api/recipes/:id` | Delete recipe |

All operations pass through security layer + input sanitization

---

## Slide 8: Docker Deployment
### Containerized Architecture

| Container | Image | Ports |
|-----------|-------|-------|
| `recipevault-frontend` | Nginx | 80:80 |
| `recipevault-api` | Node.js | 5001:5000 |
| `recipevault-mongo` | mongo:6 | 27017:27017 |

**Network**: `recipevault-network` (bridge)  
**Volume**: `mongo_data` for data persistence

---

## Slide 9: Sequence Flow (Create)
```
User → Frontend → Security → Backend → MongoDB
         ↓           ↓           ↓           ↓
      Enter Data  Rate Check  Sanitize  insertOne()
                                      ↓
User ← Frontend ← Security ← Backend
      "Recipe    201 Created
       Added"
```

---

## Slide 10: Use Cases
### Actor: User

**Read Operations**
- View Recipes List
- View Recipe Details
- Search Recipes (real-time regex)
- Filter by Category
- Sort by Date

**Write Operations**
- Create New Recipe
- Edit Recipe
- Delete Recipe (with confirmation)

---

## Slide 11: Achievements
### Project Completions ✅

1. Complete NoSQL recipe management system
2. Optimized MongoDB indexes (Text, Category, Timestamp)
3. Three-tier architecture with security layer
4. Docker Compose deployment (3 containers)
5. Demonstrated NoSQL advantages

---

## Slide 12: Future Enhancements
### What's Next?

- User authentication and recipe ownership
- Image upload for recipes
- Recipe rating and reviews
- Meal planning & shopping lists
- Fuzzy search with MongoDB Atlas Search

---

## Slide 13: NoSQL Takeaways
### Key Learnings

✅ Document-oriented storage fits recipe data naturally  
✅ Text indexes enable efficient search natively  
✅ Single-collection design simplifies queries  
✅ Flexible schema accommodates variations  
✅ MongoDB + Docker = scalable deployment

---

## Slide 14: Thank You!
# RecipeVault
### Simplifying recipe management with NoSQL

**GitHub**: [Repository Link]  
**Live Demo**: http://localhost:80

---

## Questions?
