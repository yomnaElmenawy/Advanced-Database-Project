# Project Proposal: RecipeVault
## CSE323 Advanced Database Systems

---

## 1. Project Overview
**RecipeVault** is a modern, containerized recipe management application leveraging MongoDB's NoSQL capabilities for efficient data storage and retrieval.

### Tagline
A NoSQL-based recipe management system built with MongoDB, Node.js/Express, and Nginx.

### Course Context
Submitted for CSE323 Advanced Database Systems, demonstrating practical NoSQL design and implementation.

---

## 2. Problem Statement
Traditional recipe management systems often rely on relational databases, which introduce unnecessary complexity for document-oriented data like recipes. Key pain points include:
- Complex JOIN operations for recipe data relationships
- Rigid schema constraints for varying recipe structures
- Limited native text search capabilities
- Overhead in serializing recipe ingredients/instructions

RecipeVault addresses these by:
- Eliminating JOINs with single-collection NoSQL design
- Leveraging MongoDB's flexible schema for recipe variations
- Implementing optimized weighted text search across recipe fields
- Using plain text storage for zero-serialization overhead

---

## 3. Objectives

### Primary Goals
1. Design and implement a NoSQL document store for recipe data
2. Create a responsive web interface for full CRUD operations
3. Implement efficient search and filtering using MongoDB indexes
4. Deploy a containerized application using Docker Compose

### Technical Goals
- Single-collection design (no JOINs required)
- Weighted text search index (name×10, ingredients×5, description×1)
- Rate-limited API with CORS protection
- Three-tier architecture with dedicated security layer

---

## 4. System Architecture

### High-Level Architecture
```
┌─────────────────────────────────────┐
│   Frontend (Nginx + HTML/CSS/JS)    │
│  - Recipes Grid Page                │
│  - Recipe Detail Modal              │
│  - Create/Edit Form                 │
│  - Search & Filter Bar              │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│      Security Layer                 │
│  - CORS Policy (allowedOrigins)     │
│  - Rate Limiter (100 req/15 min)    │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│  Backend (Node.js/Express 4)        │
│  - Recipe Router (/api/recipes)     │
│  - Recipe Controller (CRUD)         │
│  - Input Sanitizer                  │
│  - Mongoose ODM v7.x                │
│  - Error Handler                    │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│  MongoDB Layer                      │
│  - recipes Collection              │
│  - Text Index (weighted search)    │
│  - Category Index (enum filter)    │
│  - createdAt Index (sorting)       │
└─────────────────────────────────────┘
```

### Component Layers
- **Frontend Layer**: Static HTML/CSS/JS served via Nginx, includes recipe grid, detail modal, create/edit form, search/filter bar
- **Security Layer**: CORS policy controls allowed origins; rate limiter restricts to 100 requests per 15 minutes per IP
- **Backend Layer**: Express router dispatches to CRUD controllers, with input sanitization and Mongoose ODM for MongoDB interaction
- **MongoDB Layer**: Single `recipes` collection with three optimized indexes for performance

---

## 5. Data Modeling (NoSQL Design)

### Recipe Document Schema
| Field | Type | Constraints | Notes |
|-------|------|-------------|-------|
| `_id` | ObjectId | PK, auto | Primary key |
| `name` | String | Required, max:120 | Recipe title |
| `category` | String | Enum (6 values) | Breakfast/Lunch/Dinner/Dessert/Snack/Drink |
| `description` | String | Optional, max:500 | Recipe description |
| `prepTime` | Number | min:0, default:0 | Preparation time (minutes) |
| `cookTime` | Number | min:0, default:0 | Cooking time (minutes) |
| `servings` | Number | min:1, default:1 | Number of servings |
| `difficulty` | String | Enum: Easy/Medium/Hard | Difficulty level |
| `ingredients` | String | Newline-separated | Stored as plain text |
| `instructions` | String | Newline-separated | Step-by-step instructions |
| `createdAt` | Date | Auto (timestamps) | Creation timestamp |
| `updatedAt` | Date | Auto (timestamps) | Last update timestamp |

### Index Strategy
| Index Type | Fields | Purpose |
|------------|--------|---------|
| Text Index | `{ name: 10, ingredients: 5, description: 1 }` | Weighted full-text search |
| Category Index | `{ category: 1 }` | Fast category filtering |
| Timestamp Index | `{ createdAt: -1 }` | Sort by newest/oldest |

### NoSQL Design Benefits
- **Single-collection design**: No JOINs required, all recipe data retrieved in single `findOne()` call (O(1) by `_id`)
- **Plain text storage**: Ingredients & instructions stored as newline-separated strings for zero serialization overhead
- **Enum enforcement**: Category/difficulty enums enforced by Mongoose ODM, no foreign key tables
- **Flexible schema**: Accommodates varying recipe structures without schema migrations

---

## 6. Implementation Details

### Component Interaction Flow
```
Recipe Router (/api/recipes)
    ↓ Route dispatch
Recipe Controller (recipeController.js)
    ↓ Validate & sanitise
Input Sanitizer (sanitiseRecipeBody, escapeRegex)
    ↓ Clean data → Mongoose model
Mongoose ODM (Recipe model)
    ↓ MongoDB Wire Protocol
recipes Collection
    ↓ Accelerated by
Text Index / Category Index / Timestamp Index
```

### CRUD Operations
| Operation | HTTP Method | Endpoint | MongoDB Equivalent |
|-----------|-------------|----------|-------------------|
| Create | POST | `/api/recipes` | `insertOne()` |
| Read (all) | GET | `/api/recipes` | `find(query)` |
| Read (one) | GET | `/api/recipes/:id` | `findById(id)` |
| Update | PUT | `/api/recipes/:id` | `findByIdAndUpdate()` |
| Delete | DELETE | `/api/recipes/:id` | `findByIdAndDelete()` |

### Security Features
- **CORS Policy**: Controls allowed origins for API access
- **Rate Limiting**: 100 requests per 15 minutes per IP address
- **Input Sanitization**: `sanitiseRecipeBody` and `escapeRegex` functions prevent injection attacks
- **Mongoose Validation**: Enum and constraint validation before all database writes

---

## 7. Deployment Strategy

### Docker Compose Architecture
```
┌─────────────────────────────────────────────────────┐
│                  Docker Host                        │
│                                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────┐ │
│  │ Frontend      │  │ Backend      │  │ MongoDB  │ │
│  │ Container     │  │ Container    │  │ Container│ │
│  │ (Nginx)       │  │ (Node.js)    │  │ (v6)     │ │
│  │ Port: 80      │  │ Port: 5000   │  │ Port:    │ │
│  │               │  │              │  │ 27017    │ │
│  └──────┬───────┘  └──────┬───────┘  └────┬─────┘ │
│         │                   │               │       │
│         └───────────────────┼───────────────┘       │
│                             │                       │
│  ┌──────────────────────────────────────────────┐  │
│  │    recipevault-network (default bridge)      │  │
│  └──────────────────────────────────────────────┘  │
│                                                     │
│  ┌──────────────────────────────────────────────┐  │
│  │    mongo_data (Named Volume: /data/db)      │  │
│  └──────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

### Container Specifications
| Container | Image | Port Mapping | Dependencies |
|-----------|-------|--------------|--------------|
| `recipevault-frontend` | Custom (Nginx) | Host:80 → Container:80 | Backend (proxy `/api` → `:5000`) |
| `recipevault-api` | Custom (Node.js) | Host:5001 → Container:5000 | MongoDB (healthy) |
| `recipevault-mongo` | mongo:6 | Host:27017 → Container:27017 | `mongo_data` volume |

### Configuration
- **Environment Variable**: `MONGO_URI=mongodb://mongo:27017/recipevault`
- **Healthcheck**: MongoDB container uses `mongosh ping` for health verification
- **Network**: All services connect via `recipevault-network` (default bridge)
- **Volume**: `mongo_data` persists `/data/db` for data durability

---

## 8. Use Cases

### Actor: User
#### Read Operations
| Use Case | Description | Extends |
|----------|-------------|---------|
| View Recipes List | Display all recipes in grid layout | - |
| View Recipe Details | Show full recipe in modal | - |
| Search Recipes | Real-time regex search across name, description, ingredients | View Recipes List |
| Filter by Category | Narrow results by category enum | View Recipes List |
| Sort Recipes | Order by createdAt (newest/oldest) | View Recipes List |
| View Statistics Bar | Show recipe count and metrics | View Recipes List |

#### Write Operations
| Use Case | Description | Extends |
|----------|-------------|---------|
| Create New Recipe | Add recipe with Mongoose validation | - |
| Edit Recipe | Modify existing recipe | View Recipe Details |
| Delete Recipe | Remove recipe with confirmation | View Recipe Details |

### Notes
- Search uses real-time regex matching across multiple fields
- All write operations trigger Mongoose validation before MongoDB writes
- Rate limiting applies to all API requests (100 req/15min)

---

## 9. Conclusion

### Project Achievements
1. ✅ Implemented a complete NoSQL recipe management system
2. ✅ Designed efficient MongoDB indexes for search and filtering
3. ✅ Created a three-tier architecture with dedicated security layer
4. ✅ Deployed using Docker Compose with containerized services
5. ✅ Demonstrated NoSQL advantages: single-collection design, flexible schema

### Future Enhancements
- User authentication and recipe ownership
- Image upload for recipes
- Recipe rating and reviews
- Meal planning and shopping list features
- Advanced search with fuzzy matching

### NoSQL Takeaways
- Document-oriented storage aligns naturally with recipe data structure
- Text indexes provide efficient search without external search engines
- Single-collection design simplifies queries and improves performance
- MongoDB's flexible schema accommodates recipe variations seamlessly

---

## 10. Appendix: Sequence Flows
### Create Recipe Flow
```
User → Frontend: Enter recipe data
Frontend → Security: POST /api/recipes
Security → Security: Check rate limit (100/15min)
Security → Backend: Forward request
Backend → Backend: sanitiseRecipeBody, validate enums
Backend → MongoDB: Recipe.create(data)
MongoDB → Backend: Saved document (_id, timestamps)
Backend → Frontend: 201 Created {recipe}
Frontend → User: Toast "Recipe added" + grid updated
```

### Update Recipe Flow
```
User → Frontend: Click Edit → modify → Save
Frontend → Security: PUT /api/recipes/:id
Security → Backend: Forward (after rate check)
Backend → Backend: sanitise, whitelist fields
Backend → MongoDB: findByIdAndUpdate(id, updates)
MongoDB → Backend: Updated document
Backend → Frontend: 200 OK {recipe}
Frontend → User: Toast "Recipe updated" + refresh
```

### Delete Recipe Flow
```
User → Frontend: Click Delete → confirm
Frontend → Security: DELETE /api/recipes/:id
Security → Backend: Forward (after rate check)
Backend → MongoDB: findByIdAndDelete(id)
MongoDB → Backend: Deletion confirmed
Backend → Frontend: 200 OK {message}
Frontend → User: Toast "Recipe deleted" + remove
```
