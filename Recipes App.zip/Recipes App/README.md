# RecipeVault
A NoSQL-based recipe management system built with MongoDB, Node.js/Express, and Nginx.

## Overview
RecipeVault is a web application for managing recipes with full CRUD operations, search, filtering, and sorting. It uses a MongoDB NoSQL database with optimized indexes for fast query performance.

## Features
- Create, read, update, delete (CRUD) recipes
- Real-time search across name, ingredients, and description
- Filter by category (Breakfast, Lunch, Dinner, Dessert, Snack, Drink)
- Sort by creation date (newest/oldest)
- Responsive frontend with recipe grid, detail modal, and create/edit form
- Security: CORS policy, rate limiting (100 req/15min)
- Dockerized deployment with separate frontend, backend, and database containers

## Tech Stack
- **Frontend**: HTML, CSS, JavaScript (served via Nginx)
- **Backend**: Node.js, Express 4
- **Database**: MongoDB 6 (NoSQL)
- **ODM**: Mongoose v7.x
- **Deployment**: Docker, Docker Compose
- **Diagrams**: PlantUML

## Prerequisites
- Docker and Docker Compose installed
- Node.js (for local development)
- MongoDB (for local development)

## Quick Start (Docker)
1. Run `docker-compose up -d` from the project root
2. Access frontend at `http://localhost:80`
3. Backend API at `http://localhost:5001`

## API Endpoints
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/recipes` | List recipes (supports `search`, `category`, `sort` params) |
| GET | `/api/recipes/:id` | Get single recipe details |
| POST | `/api/recipes` | Create new recipe |
| PUT | `/api/recipes/:id` | Update existing recipe |
| DELETE | `/api/recipes/:id` | Delete recipe |

## Project Structure
```
Recipes App-main/
├── Digrams/               # System diagrams (PlantUML + images)
│   ├── Arch/              # Architecture diagram
│   ├── Component/         # Component diagram
│   ├── Datamodeling/      # Data model diagram
│   ├── Deployment/        # Deployment diagram
│   ├── Sequance/          # Sequence diagrams
│   └── UseCase/           # Use case diagram
├── backend/               # Node.js/Express backend
├── frontend/              # HTML/CSS/JS frontend
└── docker-compose.yml     # Docker Compose configuration
```

## Documentation
For detailed system design, refer to [Documentation.md](Documentation.md)
