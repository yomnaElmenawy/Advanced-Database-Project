# RecipeVault - System Documentation

## Table of Contents
1. [Architecture Overview](#architecture-overview)
2. [Component Design](#component-design)
3. [Data Model](#data-model)
4. [Deployment Architecture](#deployment-architecture)
5. [Sequence Flows](#sequence-flows)
6. [Use Cases](#use-cases)

---

## Architecture Overview

RecipeVault follows a three-tier architecture with security layer integration.

### System Architecture
```
Frontend (Nginx + HTML/CSS/JS)
    ↓
Security Layer (CORS + Rate Limiter)
    ↓
Backend (Node.js/Express 4)
    ↓
MongoDB Layer (recipes Collection + Indexes)
```

### Components
- **Frontend Layer**
  - Recipes Grid Page - displays all recipes in card layout
  - Recipe Detail Modal - shows full recipe information
  - Create/Edit Form - input form for recipe data
  - Search & Filter Bar - real-time search and category filtering

- **Security Layer**
  - CORS Policy - controls allowed origins
  - Rate Limiter - 100 requests per 15 minutes per IP

- **Backend Layer**
  - Recipe Router (`/api/recipes`) - route definitions
  - Recipe Controller - CRUD handler functions
  - Input Sanitizer - `sanitiseRecipeBody`, `escapeRegex`
  - Mongoose ODM v7.x - MongoDB object modeling
  - Error Handler - centralized error middleware

- **MongoDB Layer**
  - `recipes` Collection - main data store
  - Text Index - weighted search on name(×10), ingredients(×5), description(×1)
  - Category Index - enum-based filtering
  - createdAt Index - sort by newest/oldest

---

## Component Design

### MongoDB Document Structure
| Field | Type | Constraints |
|-------|------|-------------|
| `_id` | ObjectId | PK, auto-generated |
| `name` | String | Required, max 120 chars |
| `category` | String | Enum: Breakfast, Lunch, Dinner, Dessert, Snack, Drink |
| `description` | String | Optional, max 500 chars |
| `prepTime` | Number | min: 0, default: 0 |
| `cookTime` | Number | min: 0, default: 0 |
| `servings` | Number | min: 1, default: 1 |
| `difficulty` | String | Enum: Easy, Medium, Hard |
| `ingredients` | String | Newline-separated list |
| `instructions` | String | Newline-separated steps |
| `createdAt` | Date | Auto (timestamps) |
| `updatedAt` | Date | Auto (timestamps) |

### Index Strategy
| Index | Fields | Purpose |
|-------|--------|---------|
| Text Index | `{ name: 10, ingredients: 5, description: 1 }` | Full-text search with weighting |
| Category Index | `{ category: 1 }` | Fast category filtering |
| Timestamp Index | `{ createdAt: -1 }` | Sort by creation date |

### Component Interactions
- **Router → Controller**: Route dispatch for CRUD operations
- **Controller → ODM**: `Recipe.find(query)`, `Recipe.create(data)`, `Recipe.findByIdAndUpdate()`, `Recipe.findByIdAndDelete()`
- **ODM → Collection**: MongoDB Wire Protocol communication
- **Collection → Indexes**: Query acceleration via indexes

---

## Data Model

### Recipe Document (NoSQL Design)
```
Single-collection design - no JOINs required
ingredients & instructions stored as plain text strings
(one item per line) for natural textarea ↔ DB round-trip
```

### Enum Values
**Category Values**: Breakfast, Lunch, Dinner, Dessert, Snack, Drink
**Difficulty Values**: Easy, Medium, Hard

### Design Decisions
- No foreign key relationships - category enforced by Mongoose enum
- Single `findOne()` call retrieves all recipe data (O(1) by `_id`)
- Text indexes enable weighted full-text search
- Newline-separated strings avoid serialization overhead

---

## Deployment Architecture

### Docker Compose Setup
| Container | Image | Ports | Purpose |
|-----------|-------|-------|---------|
| `recipevault-frontend` | Custom (Nginx) | Host:80 → Container:80 | Serve static frontend |
| `recipevault-api` | Custom (Node.js) | Host:5001 → Container:5000 | Backend API |
| `recipevault-mongo` | mongo:6 | Host:27017 → Container:27017 | MongoDB database |

### Volume
- **mongo_data**: Persists `/data/db` directory for MongoDB data persistence

### Network
- **recipevault-network**: Default bridge network connecting all containers

### Service Dependencies
- Frontend depends on Backend (proxy `/api` requests to `:5000`)
- Backend depends on MongoDB (with healthcheck: `mongosh ping`)
- All services connect to `recipevault-network`

### Environment Variables
- `MONGO_URI=mongodb://mongo:27017/recipevault`

---

## Sequence Flows

### Flow 1: Create Recipe
```
User → Frontend: Enter recipe data
Frontend → Backend: POST /api/recipes {name, category, ...}
Backend → MongoDB: insertOne(recipeDoc)
MongoDB → Backend: Document created (ObjectId assigned)
Backend → Frontend: 201 Created {_id, name, category, ...}
Frontend → User: Success toast + grid re-rendered
```

### Flow 2: View Recipe
```
User → Frontend: Click recipe card
Frontend → Backend: GET /api/recipes/:id
Backend → MongoDB: findById(id)
MongoDB → Backend: Recipe document
Backend → Frontend: 200 OK {_id, name, ingredients, ...}
Frontend → User: Recipe detail modal displayed
```

### Flow 3: Update Recipe
```
User → Frontend: Click Edit → modify → Save
Frontend → Security: PUT /api/recipes/:id {updated fields}
Security → Security: Check rate limit
Security → Backend: Forward request
Backend → Backend: sanitiseRecipeBody(body), whitelist fields
Backend → MongoDB: findByIdAndUpdate(id, updates, {new:true, runValidators:true})
MongoDB → Backend: Updated document
Backend → Frontend: 200 OK {recipe}
Frontend → User: Toast "Recipe updated" + card refreshed
```

### Flow 4: Delete Recipe
```
User → Frontend: Click Delete → confirm dialog
Frontend → Security: DELETE /api/recipes/:id
Security → Security: Check rate limit
Security → Backend: Forward request
Backend → MongoDB: findByIdAndDelete(id)
MongoDB → Backend: Deleted document confirmation
Backend → Frontend: 200 OK {message: "Recipe deleted"}
Frontend → User: Toast "Recipe deleted" + card removed
```

---

## Use Cases

### Actor: User

#### Read Operations
| Use Case | Description | Extends |
|----------|-------------|---------|
| View Recipes List | Display all recipes in grid layout | - |
| View Recipe Details | Show full recipe in modal | - |
| Search Recipes | Real-time regex search across name, description, ingredients | View Recipes List |
| Filter by Category | Narrow results by category enum | View Recipes List |
| Sort Recipes | Order by createdAt (newest/oldest) | View Recipes List |
| View Statistics Bar | Show recipe count and metrics | View Recipes List |

#### Write Operations
| Use Case | Description | Extends |
|----------|-------------|---------|
| Create New Recipe | Add recipe with validation | - |
| Edit Recipe | Modify existing recipe | View Recipe Details |
| Delete Recipe | Remove recipe with confirmation | View Recipe Details |

### Notes
- Search uses real-time regex matching across multiple fields
- All write operations trigger Mongoose validation before MongoDB write
- Rate limiting applies to all API requests (100 req/15min)
